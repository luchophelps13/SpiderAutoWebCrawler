SpiderWebCrawler is a library to automatically complete web-scraping related tasks such as:
=================================
finding element(s) by class or ID, 
finding elements by XPATH, 
finding tables, paragraphs, headers, footers, headings, images, etc., 
finding images' source, 
finding and returning images!
----------------------------------
